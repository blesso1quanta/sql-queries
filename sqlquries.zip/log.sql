-- Keep a log of any SQL queries you execute as you solve the mystery.
.tables;
.schema crime_scene_reports;
SELECT description FROM crime_scene_reports WHERE month = 7 AND day = 28 AND year = 2020 AND street = "Chamberlin Street";
-- Theft of the CS50 duck took place at 10:15am at the Chamberlin Street courthouse. Interviews were conducted today with three witnesses who were present at the time — each of their interview transcripts mentions the courthouse.
.schema interviews;
SELECT name,transcript FROM interviews WHERE month = 7 AND day = 28 AND year = 2020;
-- name | transcript
--Jose | “Ah,” said he, “I forgot that I had not seen you for some weeks. It is a little souvenir from the King of Bohemia in return for my assistance in the case of the Irene Adler papers.”
--Eugene | “I suppose,” said Holmes, “that when Mr. Windibank came back from France he was very annoyed at your having gone to the ball.”
--Barbara | “You had my note?” he asked with a deep harsh voice and a strongly marked German accent. “I told you that I would call.” He looked from one to the other of us, as if uncertain which to address.
--Ruth | Sometime within ten minutes of the theft, I saw the thief get into a car in the courthouse parking lot and drive away. If you have security footage from the courthouse parking lot, you might want to look for cars that left the parking lot in that time frame.
--Eugene | I don't know the thief's name, but it was someone I recognized. Earlier this morning, before I arrived at the courthouse, I was walking by the ATM on Fifer Street and saw the thief there withdrawing some money.
--Raymond | As the thief was leaving the courthouse, they called someone who talked to them for less than a minute. In the call, I heard the thief say that they were planning to take the earliest flight out of Fiftyville tomorrow. The thief then asked the person on the other end of the phone to purchase the flight ticket.
.schema crime_scene_reports;
SELECT license_plate , activity , minute FROM courthouse_security_logs WHERE year = 2020 AND day = 28 AND month = 7 AND hour = 10;
--5P2BI95 | exit | 16
--94KL13X | exit | 18
--6P58WS2 | exit | 18
--4328GD8 | exit | 19
--G412CB7 | exit | 20
--L93JTIZ | exit | 21
--322W7JE | exit | 23
--0NTHK55 | exit | 23
--1106N58 | exit | 35
.schema atm_transactions;
SELECT account_number , amount FROM atm_transactions WHERE year = 2020 AND day = 28 AND month = 7 AND atm_location = "Fifer Street" AND transaction_type = "withdraw";
account_number | amount
--28500762 | 48
--28296815 | 20
--76054385 | 60
--49610011 | 50
--16153065 | 80
--25506511 | 20
--81061156 | 30
--26013199 | 35
SELECT name FROM people WHERE id IN (SELECT person_id FROM bank_accounts WHERE account_number IN (SELECT account_number FROM atm_transactions WHERE year = 2020 AND day = 28 AND month = 7 AND atm_location = "Fifer Street" AND transaction_type = "withdraw"));
--name
--Elizabeth
--Victoria
--Madison
--Roy
--Danielle
--Russell
--Ernest
SELECT name FROM people WHERE license_plate IN (SELECT license_plate FROM courthouse_security_logs WHERE year = 2020 AND day = 28 AND month = 7 AND hour = 10 AND minute <= 25 AND minute >= 15 AND activity = "exit");
--name
Patrick
Amber
Elizabeth
Roger
Danielle
Russell
Evelyn
Ernest
SELECT origin_airport_id , destination_airport_id FROM flights WHERE year = 2020 AND month = 7 AND day = 29;
--8 | 6
--8 | 11
--8 | 4
--8 | 1
--8 | 9
SELECT city FROM airports WHERE id IN (SELECT destination_airport_id FROM flights WHERE year = 2020 AND month = 7 AND day = 29);
--city
--Chicago
--London
--Boston
--Tokyo
--San Francisco
SELECT city FROM airports WHERE id IN (SELECT DISTINCT origin_airport_id FROM flights WHERE year = 2020 AND month = 7 AND day = 29);
--Fiftyville
SELECT id FROM flights WHERE year = 2020 AND month = 7 AND day = 29;
--18
--23
--36
--43
--53
SELECT passport_number FROM passengers WHERE flight_id IN (SELECT id FROM flights WHERE year = 2020 AND month = 7 AND day = 29);
SELECT name FROM people WHERE passport_number IN (SELECT passport_number FROM passengers WHERE flight_id IN (SELECT id FROM flights WHERE year = 2020 AND month = 7 AND day = 29));
Pamela
Jordan
Heather
Larry
Diana
Brandon
Rebecca
Marilyn
Bobby
Roger
Carol
Dennis
Madison
Roy
Danielle
Russell
Michael
Evelyn
Matthew
Melissa
Edward
Thomas
Steven
John
Ethan
Ernest
Richard
Sophia
Daniel
Jennifer
Douglas
Charles
Emily
Gloria
Jose
Christian
Doris
.schema phone_calls;
SELECT caller , receiver FROM phone_calls WHERE year = 2020 AND month = 7 AND day = 28 AND duration <= 60;
SELECT name FROM people WHERE phone_number IN (SELECT caller FROM phone_calls WHERE year = 2020 AND month = 7 AND day = 28 AND duration < 60);
Bobby
Roger
Victoria
Madison
Russell
Evelyn
Kathryn
Ernest
Kimberly
--main suspects
russell
ernest
SELECT * FROM flights WHERE year = 2020 AND month = 7 AND day = 29;
id | origin_airport_id | destination_airport_id | year | month | day | hour | minute
18 | 8 | 6 | 2020 | 7 | 29 | 16 | 0
23 | 8 | 11 | 2020 | 7 | 29 | 12 | 15
36 | 8 | 4 | 2020 | 7 | 29 | 8 | 20
43 | 8 | 1 | 2020 | 7 | 29 | 9 | 30
53 | 8 | 9 | 2020 | 7 | 29 | 15 | 20
--ID 36 is the earliset flight
SELECT name FROM people WHERE passport_number IN (SELECT passport_number FROM passengers WHERE flight_id = 36);
Bobby
Roger
Madison
Danielle
Evelyn
Edward
Ernest
Doris
-- ERNEST IS THE THEIF--
SELECT city FROM airports WHERE id = 4;
--THE CITY IS LONDON--
SELECT phone_number FROM people WHERE name="Ernest";
SELECT receiver FROM phone_calls WHERE caller = (SELECT phone_number FROM people WHERE name="Ernest" AND year = 2020 AND month = 7 AND day = 28 AND duration < 60);
SELECT name FROM people WHERE phone_number = (SELECT receiver FROM phone_calls WHERE caller = (SELECT phone_number FROM people WHERE name="Ernest" AND year = 2020 AND month = 7 AND day = 28 AND duration < 60));
--THE ACCOMPLICE IS Berthold --














